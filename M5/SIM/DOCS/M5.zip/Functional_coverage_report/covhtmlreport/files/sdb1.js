var g_db_data = {"4":1};
processScopesDbFile(g_db_data);