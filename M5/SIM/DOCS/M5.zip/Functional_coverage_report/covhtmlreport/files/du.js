var g_data = {"data":[{"n":"work.tb_top","id":4,"zf":1,"tc":95.45,"g":95.45}]};
processDuData(g_data);