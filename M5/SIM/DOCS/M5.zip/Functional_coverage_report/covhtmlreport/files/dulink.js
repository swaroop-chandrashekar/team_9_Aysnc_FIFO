var g_data = {"4":["work.tb_top",95.45,1]};
processDuLinks(g_data);